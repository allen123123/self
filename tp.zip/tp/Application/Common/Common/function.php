<?php
function show($arr){
	echo '<pre>' . print_r($arr, true) . '</pre>';
}

function verify_check($code, $id='')
{
   
    $verify = new \Think\Verify();
    return $verify->check($code, $id);
}


function node_merge($node,$access=null,$pid =0)
{
    $arr=array();
    foreach ($node as $v)
    {
        if(is_array($access))
        {
            $v['access'] =in_array($v['id'],$access)?1:0;
        }
        if($v['pid']==$pid) //如果穿过来的$node【‘pid’】是0
        {
            $v['child'] =node_merge($node,$access,$v['id']);//在二维数组增加一个child字段,并且将pid赋值为当前一维数组的pid
            $arr[] =$v;
        }
    }
    return $arr;//输出二维数组
}
?>