<?php
return array(
    'DB_TYPE'               =>  'mysql',     // 数据库类型
    'DB_HOST'               =>  'rds4un3yk0a8ok1s415z.mysql.rds.aliyuncs.com:3306', // 服务器地址
    'DB_NAME'               =>  'daoshan',          // 数据库名
    'DB_USER'               =>  'daoshan',      // 用户名
    'DB_PWD'                =>  'daoshan_akaj5080',          // 密码
    'DB_PREFIX'             =>  '',    // 数据库表前缀


    'TMPL_PARSE_STRING'     => array (
        '_CSS' =>__ROOT__.'/'.APP_PATH.'Public/static',
    ),
	'URL_CASE_INSENSITIVE'  =>  true,
    'TMPL_FILE_DEPR'        =>'_',
    //'TMPL_EXCEPTION_FILE'   =>APP_PATH.'/admin/View/error.html',
    'TMPL_VAR_IDENTIFY'     =>'array',
    'URL_HTML_SUFFIX'       => '',
    //'DEFAULT_MODULE'       => 'Home,Admin',
    'RBAC_SUPERADMIN' => 'admin',				//超级管理员名称
    'ADMIN_AUTH_KEY' => 'superadmin',			//超级管理员识别号
    'USER_AUTH_ON' => true,						//是否开启验证
    'USER_AUTH_KEY'=>'uid',
    'USER_AUTH_TYPE'=>1,
    'USER_AUTH_GATEWAY' =>'/login/index',
    //'NOT_AUTH_ACTION' =>'',         //无需验证的方法,在各分组设置
    'GUEST_AUTH_ON'  => false,    // 是否开启游客授权访问
    'GUEST_AUTH_ID'  =>    0,     // 游客的用户ID
    'RBAC_ROLE_TABLE'=>'think_role', //角色表名称
    'RBAC_USER_TABLE' => 'think_role_user', //中间表
    'RBAC_ACCESS_TABLE'=>'think_access',
    'RBAC_NODE_TABLE' =>'think_node',
	'URL_MODEL'             =>  1,
   

);