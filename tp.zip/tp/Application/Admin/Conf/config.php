<?php /*最高优先级配置项*/

return array(

'NOT_AUTH_MODULE' =>'',
'NOT_AUTH_ACTION' =>'addUserHandle,addRoleHandle,addnodehandle,setaccess,addCate,AddBlogHandle,AddCateHandle,deleteCate,Blog_SortCateHandle,AddAttr,AddAttrHandle,DeleteAttr,blog_edit,addBlog,blog_toTrash,delete_blog,blog_emptyTrash,goods_cate_add,goods_add_attr,
goods_add,goods_add_handle,goods_add_attr_handle,goods_delete_attr,goods_toTrash,goods_delete,goods_emptyTrash,goods_cate_add_handle,course_add,course_add_handle,course_cate_add,course_cate_add_handle,course_attr_add,course_attr_add_handle,course_attr_show,',
);

?>