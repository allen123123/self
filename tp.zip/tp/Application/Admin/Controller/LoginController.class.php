<?php
namespace Admin\Controller;
use Think\Controller;
use Org\Util\Rbac;
class LoginController extends Controller
{
    public function login()
    {

        $this->display('admin_login');
    }
    public function check()
    {
        if(!IS_POST) $this->error('非法参数','javascript:history.back(-1)',1);
        $code     =I('post.verify');

        if(!verify_check($code))
        {

            $this->error('验证码错误','login/login',1);
        }
        $username =I('post.username');
        $password =I('post.password','','md5');
        $user = M('admin_user')->where(array('name'=>$username))->find();

        if(!$user || $user['password']!=$password)
        {
            $this->error('账号或密码错误','login/login',1);
        }
        if($user['is_lock'] ==1) $this->error('账号被锁定');
        if($user['vip']==1) $this->error('非法参数','javascript:history.back(-1)',1);
        $data =array(
            'userid'=>$user['userid'],
            'logintime'=>time(),
            'loginip'=>get_client_ip(),
            'loginnum'=>$user['loginnum']+1,
        );
        M('admin_user')->save($data);
        session(C('USER_AUTH_KEY'),$user['userid']);
        session('username',$user['name']);
        //session('nickname',$user['nickname']);
        session('logintime',date('Y-m-d H:i:s',$user['logintime']));
        if($user['name'] ==C('RBAC_SUPERADMIN')) {
            session(C('ADMIN_AUTH_KEY'),true);
        }else {
            Rbac::saveAccessList($user['userid']);

        }
        $this->redirect('index/index');
    }

public function loginout()
{
    session_unset();
    session_destroy();
    $this->redirect('login/login');
}

    /*public function register()
    {
        if (IS_POST) {
            // 实例化User对象
            $user = D('member');
            // 自动验证 创建数据集
            if (!$data =$user->create()) {
                // 防止输出中文乱码
                header("Content-type: text/html; charset=utf-8");
                $this->error($user->getError(),'javascript:history.back(-1)',1);
            }
            //插入数据库
            if ($id=$user->add($data)) {
                $this->success('注册成功', U('login/login'), 1);
            } else {
                $this->error('注册失败');
            }
        } else {
            $this->display('admin_register');
        }

      }*/

    public function verify()
    {
        ob_clean();   //请缓存
        $verify = new \Think\Verify();

        // 配置验证码参数
        $verify->fontSize = 18;     // 验证码字体大小
        $verify->length =2;        // 验证码位数
        $verify->imageH = 38;       // 验证码高度
        $verify->useImgBg = false;   // 开启验证码背景
        $verify->useNoise = false;  // 关闭验证码干扰杂点
        $verify->reset =false;
        $verify->entry();
    }
}
?>