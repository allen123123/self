<?php
namespace Admin\Controller;
use Think\Controller;
use Admin\lib\Category;
class CourseController extends Controller
{

    public function index()
    {

        $this->data=D('CourseRel')->relation(true)->select();

        $this->display('Course/course_index');
    }

    public function course_edit()
    {

        $this->error('正在完善',U("index"),1);
    }


    public function course_add()
    {
        $cate = M('admin_course_cate')->order('sort ASC')->select();
        $this->cate = Category::unlimitForLevel($cate);
        $this->attr = M('admin_course_attr')->where(array('pid'=>0))->select();
        $this->display('Course/course_add');
    }


    public function course_add_handle()
    {
        if(!IS_POST) $this->error('非法参数');
        $data =array(
            'name'=>I('name'),
            'cid'=>I('cid'),
            'is_show'=>I('is_show'),
            'uptime'=>time(),
            'droptime'=>strtotime(I('droptime')),
            'bnf_price'=>I('bnf_price','','intval'),
            'price'=>I('price','','intval'),
            'limit_join'=>I('limit_join','','intval'),
            'content'=>I('content'),
            'summary'=>I('summary'),

        );
        if($_FILES['teacherimg'])
        {
            $upload = new \Think\Upload();// 实例化上传类
            $upload->saveName = 'time';
            $upload->maxSize = 3145728;// 设置附件上传大小
            $upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
            $upload->rootPath = 'Public/'; // 设置附件上传根目录
            $upload->savePath = 'Uploads/teacherimg/'; // 设置附件上传（子）目录
            // 上传文件
            $info = $upload->uploadOne($_FILES['teacherimg']);
            if(!$info) {// 上传错误提示错误信息
               $this->error($upload->getError());

            }else{
                $data['teacherimg'] = "http://www.daoshanedu.com" . __ROOT__ . '/' . 'Public/' . $info['savepath'] . $info['savename'];
            }
        }
        if($_FILES['coverimg']) {
            $upload = new \Think\Upload();// 实例化上传类
            $upload->saveName = 'time';
            $upload->maxSize = 3145728;// 设置附件上传大小
            $upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
            $upload->rootPath = 'Public/'; // 设置附件上传根目录
            $upload->savePath = 'Uploads/Coverimg/'; // 设置附件上传（子）目录
            // 上传文件
            $info = $upload->uploadOne($_FILES['coverimg']);
            if(!$info) {// 上传错误提示错误信息

                $this->error($upload->getError());
            }else{
                $data['coverimg'] = "http://www.daoshanedu.com" . __ROOT__ . '/' . 'Public/' . $info['savepath'] . $info['savename'];
            }
        }
        if(isset($_POST['aid'])){
            foreach ($_POST['aid'] as $v){
                $data['attr'][] = $v;
            }
        }
        $course = D('CourseRel');
        if($course->relation(true)->add($data))
        {
            echo "<script> alert('添加成功'); </script>";
        } else {
            echo "<script> alert('添加失败'); </script>";
        }

    }

    public function course_cate()
    {
        $cate = M('admin_course_cate')->order('sort ASC')->select();

        $cate = Category::unlimitForLevel($cate, '|--');

        $this->assign('cate', $cate);

        $this->display('Course/course_cate');

    }

    public function course_cate_add()
    {
        $pid = I('pid', 0, 'intval');
        $this->assign('pid', $pid)->display('Course/course_cate_add');
    }

    public function course_cate_add_handle()
    {
        $name = trim(I('name'));
        if (empty($name)) {
            $this->error('名称不能为空！');
        }

        $db = M('admin_course_cate');
        if ($db->create()) {
            if ($db->add()) {
                $this->success('添加成功！', U('course_cate'), 1);
            } else {
                $this->error('添加失败！');

            }

        }

    }


    public function course_attr()
    {
        $data = M('admin_course_attr')->order('sort ASC')->select();

        $attr = Category::unlimitForLevel($data, '|--');

        $this->assign('attr', $attr);

        $this->display('Course/course_attr');


    }

    public function course_attr_add()
    {
        $pid = I('pid', 0, 'intval');
        $this->assign('pid', $pid)->display('Course/course_attr_add');

    }

    public function course_attr_add_handle()
    {
        $name = trim(I('name'));
        if (empty($name)) {
            $this->error('名称不能为空！');
        }

        $db = M('admin_course_attr');
        if ($db->create()) {
            if ($db->add()) {
                $this->success('添加成功！', U('course_attr'), 1);
            } else {
                $this->error('添加失败！');
            }
        }
    }
    public function course_attr_show()
    {
        $id =I('aid');
        if($id)
        {
            $data = M('admin_course_attr')->where(array('pid'=>$id))->select();
            echo json_encode($data);
        }
    }

    public function course_trash()
    {
        $this->error('正在完善',U('index'),1);

    }

}
?>