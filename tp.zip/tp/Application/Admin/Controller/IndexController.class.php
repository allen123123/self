<?php
namespace Admin\Controller;
use Think\Controller;
class IndexController extends CommonController {
    public function index(){


    $this->display('admin_index');
	 
	
	}

    public function add()
    {

    }
    public function edit()
    {

    }

    public function delete()
    {

    }
    public function delDirAndFile($dirName){
        if ( $handle = opendir( "$dirName" ) ) {
            while ( false !== ( $item = readdir( $handle ) ) ) {
                if ( $item != "." && $item != ".." ) {
                    if ( is_dir( "$dirName/$item" ) ) {
                        delDirAndFile( "$dirName/$item" );
                    } else {
                        unlink( "$dirName/$item" );
                    }
                }
            }
            closedir( $handle );
            if( rmdir( $dirName ) ) return true;
        }
    }

    //清除缓存
    public function clear_cache(){
        $str = I('clear');	//防止搜索到第一个位置为0的情况
        if($str){
            //strpos 参数必须加引号
            //删除Runtime/Cache/admin目录下面的编译文件
            if(strpos("'".$str."'", '1')){
                $dir = APP_PATH.'Runtime/Cache/Admin/';
                $this->delDirAndFile($dir);
            }
            //删除Runtime/Cache/Home目录下面的编译文件
            if(strpos("'".$str."'", '2')){
                $dir = APP_PATH.'Runtime/Cache/Home/';
                $this->delDirAndFile($dir);
            }
            //删除Runtime/Data/目录下面的编译文件
            if(strpos("'".$str."'", '3')){
                $dir = APP_PATH.'Runtime/Data/';
                $this->delDirAndFile($dir);
            }
            //删除Runtime/Temp/目录下面的编译文件
            if(strpos("'".$str."'", '4')){
                $dir = APP_PATH.'Runtime/Temp/';
                $this->delDirAndFile($dir);
            }
            $this->ajaxReturn(1);	//成功
        }else{
            $this->display();
        }
    }


}