<?php
namespace Admin\Controller;

interface test
{
   public function inter($a,$b);


}

class q implements test
{
    function inter($a,$b)//
    {
        return "结果是111".($a+$b);

    }
}

class w implements test
{
    function inter($a,$b)
    {
        return "结果=".($a-$b);
    }
}

class xx
{
    private $a;
    private $b;
    public function __construct($a,$b)
    {
        $this->a=$a;
        $this->b=$b;
    }

    function display(test $a)
    {
        return "用接口开发".$a->inter($this->a,$this->b);
    }
}

$e =new xx(2,1);
$e1 = new w();
echo $e->display($e1);

?>
