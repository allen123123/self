<?php
namespace Admin\Controller;
use Think\Controller;
class ManageController extends Controller
{
    public function myadjust()
    {
        $this->display('manage_adjust');
    }
}
?>