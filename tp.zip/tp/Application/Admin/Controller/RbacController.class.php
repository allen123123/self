<?php
namespace Admin\Controller;
use Think\Controller;
class RbacController extends CommonController
{

    public  function index() //用户列表
    {
        $this->user = D('UserRelation')->where('vip=0')->field('password', true)->relation('role')->select();

        $this->display('AdminRbac/rbac_index');

    }
    //添加用户表单处理
    public function addUserHandle(){


        $user = array(
            'name' => $_POST['name'],
            'password' => md5($_POST['password']),
            'regip' =>get_client_ip(),
           'regdate'=>time(),
        );
        if($uid = M('admin_user')->add($user)){

            foreach($_POST['role_id'] as $v){

                $role[] = array(
                    'role_id' => $v,
                    'user_id' => $uid,
                );
            }
            M('think_role_user')->addAll($role);
            $this->success('添加成功', 'index');
        } else {
            $this->error('添加失败');
        }


    }
    //删除角色
    public function delete_user()
    {
        $arrid =I('rid');
        $delete = M('admin_user')->where(array('userid='.$arrid))->delete();
        if($delete)
        {
            $role_user =M('think_role_user')->where(array('user_id='.$arrid))->delete();
            if($role_user)
            {
                $this->success('删除成功',U('index'),1);
            }else{
                $this->error('删除失败',U('index'),1);
            }
        }else{
            $this->error('删除失败',U('index'),1);
        }
    }
    public function Role() //角色列表
    {
        $role =M('think_role')->where('module=0')->select();
        $this->assign('role',$role);

        $this->display('AdminRbac/rbac_role');
    }
    //节点列表
    public function node()
    {
        $field=array('id','name','title','pid');
        $node = M('think_node')->where('module=0')->field($field)->order('sort')->select();
        $this->node = node_merge($node);//合并数组,可分出多维
        $this->display('AdminRbac/rbac_node');
    }
    //添加用户
    public function addUser()
    {
        $this->role =M('think_role')->select();
        $this->display('AdminRbac/rbac_adduser');


    }
    //添加角色
    public function addRole()
    {
        $this->display('AdminRbac/rbac_addrole');

    }
    //添加角色表单处理
    public function addRoleHandle()
    {
        if(M('think_role')->add($_POST))
        {
            $this->success('添加成功',U('rbac/role'));
        }else{
            $this->error('添加失败',U('rbac/addrole'));
        }
    }
    //添加节点
    public function addNode()
    {
        $this-> pid=I('pid',0,'intval');
        $this->level =I('level',1,'intval');
        switch($this->level)
        {
            case 1:
                $this->type='应用';
                break;
            case 2;
                $this->type='控制器';
                break;
            case 3:
                $this->type ='动作方法';
                break;
        }
        $this->display('AdminRbac/rbac_addnode');
    }
    public function addnodehandle()
    {
        if(M('think_node')->add($_POST))
        {
            $this->success('添加成功',U('rbac/node'),1);
        }else{
            $this->error('添加失败',U('rbac/addnode'),1);
        }
    }
    //配置权限方法
    public function access()
    {
        $rid =I('rid',0,'intval');//获取角色id
        $field =array('id','name','title','pid');
        $node =M('think_node')->field($field)->order('sort')->select();//筛选节点字段
        $access =M('think_access')->where(array('role_id'=>$rid))->getField('node_id',true);//原有权限 gF,true则返回多行数组原本是返回单行
        $this->node = node_merge($node,$access);
        $this->rid=$rid;
        $this->display('AdminRbac/rbac_access');
    }
    //修改权限
    public function setaccess()
    {
        $rid=I('rid',0,'intval');
        $db=M('think_access');
        $db->where(array('role_id'=>$rid))->delete();
        $data =array();
        foreach($_POST['access'] as $v)
        {
            $tmp =explode('_',$v);
            $data[] =array(
                'role_id' =>$rid,
                'node_id'=>$tmp[0],
                'level' =>$tmp[1],
            );
        }
        if($db->addALL($data)){
            $this->success('修改成功',U('role'),1);
        }else{
            $this->error('修改失败',U('access'),1);
        }
    }

    public function lock()
    {
        $user =M('admin_user');
        if($lockuser =$user->where('userid='.I('rid') AND 'is_lock=1'))
        {
            $data['is_lock']=0;
            $unlock = $lockuser->save($data);

        }else{
            $data['is_lock']=1;
            $lock =$user->where('userid='.I('rid'))->save($data);
        }

        if($lock||$unlock)
        {
            $this->success('修改成功',U('index'),1);
        }else{
            $this->error('修改失败',U('index'),1);
        }
    }
}
?>