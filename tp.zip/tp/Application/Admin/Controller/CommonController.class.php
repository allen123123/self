<?php

namespace Admin\Controller;
use Think\Controller;
use Org\Util\Rbac;
class CommonController extends Controller
{
    public static $userid = '';

    public function _initialize()
    {

        if (session('uid')) {
            $this->userid = session('uid');
        } else {
            $this->error('对不起,您还没有登录,正跳转至登录面...', U('login/login'),1);
        }
        $notAuth =in_array(MODULE_NAME,explode(',',C('NOT_AUTH_MODULE'))) ||
            in_array(ACTION_NAME,explode(',',C('NOT_AUTH_ACTION')));
        if(C('USER_AUTH_ON') && !$notAuth)
        {
            Rbac::AccessDecision() || $this->error('没有权限','#',1);
        }

    }
}
?>