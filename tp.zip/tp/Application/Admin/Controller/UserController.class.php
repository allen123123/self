<?php
namespace Admin\Controller;
use Think\Controller;
class UserController extends Controller {
    public function index()
    {
        $this->user=D('UserRelation')->where('vip=1')->field('password', true)->relation('role')->select();
        $this->display('admin_users');
    }

    public function edit()
    {
        $id =I('rid');
        $sid=session('sid',$id);
        if(IS_POST){
         $data=array(
             //其他参数不接受,因为用户数据不能随意改
             'status'=>I('status'),
             'role_id'=>I('role_id'),
         );
            $savestatus=M('admin_user')->where(array('userid'=>$sid))->field('status')->save($data);
            $saverole= M('think_role_user')->where(array('user_id'=>$sid))->field('role_id')->save($data);
          if($saverole || $savestatus)
          {
              $this->success('修改成功',U('index'),1);
//              redirect(U('index'));
              unset($_SESSION['sid']);

          }else{
              $this->error('修改失败',U('index'),1);
              unset($_SESSION['sid']);
          }
        }else{
            $this->vipuser =M('admin_user')->where('userid='.$id)->find();

            $this->role=M('think_role_user')->where('user_id='.$id)->find();
            $this->display('UserRbac/Frbac_edit');
        }
    }

//    public function csc()
//    {
//        $this->display('UserRbac/Frbac_chooseschool');
//    }
   //用户组
    public function group()
    {
        $role =M('think_role')->where('module=1')->select();
        $this->assign('role',$role);

        $this->display('UserRbac/Frbac_role');
    }
    //添加角色
    public function addrole()
    {
       $this->display('UserRbac/Frbac_addrole');
    }
   //添加角色处理
    public function addRoleHandle()
    {
        if(M('think_role')->add($_POST))
        {
            $this->success('添加成功',U('user/group'));
        }else{
            $this->error('添加失败',U('user/addrole'));
        }
    }
   //节点列表
    public function node()
    {
        $field=array('id','name','title','pid');
        $node = M('think_node')->where('module=1')->field($field)->order('sort')->select();
        $this->node = node_merge($node);//合并数组,可分出多维
        $this->display('UserRbac/Frbac_node');
    }
    //添加节点
    public function addNode()
    {
        $this-> pid=I('pid',0,'intval');
        $this->level =I('level',1,'intval');

        switch($this->level)
        {
            case 1:
                $this->type='应用';
                break;
            case 2;
                $this->type ='控制器';
                break;
            case 3:
                $this->type ='动作方法';
                break;
        }
        $this->display('UserRbac/Frbac_addnode');
    }

    //添加节点处理
    public function addnodehandle()
    {
        if(M('think_node')->add($_POST))
        {
            $this->success('添加成功',U('user/node'),1);
        }else{
            $this->error('添加失败',U('user/addnode'),1);
        }
    }
   //添加权限
    public function access()
    {
        $rid =I('rid',0,'intval');//获取角色id
        $field =array('id','name','title','pid');
        $node =M('think_node')->where('module=1')->field($field)->order('sort')->select();//筛选节点字段
        $access =M('think_access')->where(array('role_id'=>$rid))->getField('node_id',true);//原有权限 gF,true则返回多行数组原本是返回单行
        $this->node = node_merge($node,$access);
        $this->rid=$rid;
        $this->display('UserRbac/Frbac_access');
    }
    //修改权限
    public function setaccess()
    {
        $rid=I('rid',0,'intval');
        $module =I('module');
        $db=M('think_access');
        $db->where(array('role_id'=>$rid,'module'=>$module))->delete();
        $data =array();
        foreach($_POST['access'] as $v)
        {
            $tmp =explode('_',$v);
            $data[] =array(
                'role_id' =>$rid,
                'node_id'=>$tmp[0],
                'level' =>$tmp[1],
                'module'=>$module,
            );
        }
        if($db->addALL($data)){
            $this->success('修改成功',U('user/group'),1);
        }else{
            $this->error('修改失败',U('user/group'),1);
        }
    }

    public function lock()
    {
        $user =M('admin_user');
        if($lockuser =$user->where('userid='.I('rid') AND 'is_lock=1'))
        {
            $data['is_lock']=0;
            $unlock = $lockuser->save($data);

        }
        if($lockuser =$user->where('userid='.I('rid') AND 'is_lock=0'))
        {
            $data['is_lock']=1;
            $lock =$user->where('userid='.I('rid'))->save($data);
        }

        if($lock||$unlock)
        {
            $this->success('修改成功',U('index'),1);
        }else{
            $this->error('修改失败',U('index'),1);
        }
    }
}