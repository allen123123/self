<?php 
namespace Admin\Controller;
use Think\Controller;
use Admin\lib\Category;
// use Think\upload;
class GoodsController extends CommonController
{
	//商品列表
	public function index()
	{

		$this->goods = D('Goods')->relation(true)->select();
		$this->display('Goods/goods_index');
	}

	//添加商品
	public function goods_add()
	{
		$cate = M('admin_goods_cate')->order('sort ASC')->select();
		$this->cate = Category::unlimitForLevel($cate);
		$this->attr = M('admin_goods_attr')->where(array('pid'=>0))->select();
		$this->display('Goods/goods_add');
	}

	public function goods_add_handle()
	{
        $data =array(
			'title'=>I('title'),
			'content'=>I('content'),
			'cid' =>I('cid','','intval'),
			'price'=>I('price'),
			'bnf_price'=>I('bnf_price'),
			'study_time'=>I('study_time'),
			'is_show'=>I('is_show'),
			'usedate'=>I('usedate'),
			'teacher'=>I('teacher'),
			'stage'=>I('stage'),
			'start'=>strtotime(I('start')),
			'click'=>I('click'),
			'uptime'=>time(),
			'limitdate'=>strtotime(I('limitdate')),
			'droptime'=>strtotime(I('droptime')),
			'limit_join'=>I('limit_join'),
		);
		if(isset($_POST['aid']))
		{
			foreach ($_POST['aid'] as $v){
				$data['attr'][] = $v;
			}
		}
		$goods=D('Goods');
		if($goods->relation(true)->add($data)){
			echo "<script> alert('添加成功'); </script>";
		} else {
			echo "<script> alert('添加失败'); </script>";
		}

	}

	public function goods_edit(){

		$id =I('rid');
		$bid=session('gid',$id);
		if(IS_POST)
		{
			$data= array(
				'title'=>I('title'),
				'content'=>I('content'),
				'cid' =>I('cid','',intval),
				'price'=>I('price'),
				'bnf_price'=>I('bnf_price'),
				'uptime'=>strtotime(I('uptime')),
				'limitdate'=>strtotime(I('limitdate')),
				'droptime'=>strtotime(I('droptime')),
				'limit_join'=>I('limit_join'),
			);
			if(isset($_POST['aid'])){
				foreach ($_POST['aid'] as $v){
					$data['attr'][] = $v;
				}
			}

			$goods = D('Goods');
			if($goods->relation(true)->where(array('id'=>$bid))->save($data)){
				$this->success('修改成功',U('Index'),1);
				unset($_SESSION['gid']);
				exit;
			} else {
				$this->error('失败',U('Index'),1);
				unset($_SESSION['gid']);
				exit;
			}

		}else {
			$this->data=D('Goods')->where(array('id'=>$id))->relation(true)->find();
			$cate = M('admin_goods_cate')->order('sort ASC')->select();
			$this->cate = Category::unlimitForLevel($cate);
			$this->attr = M('admin_goods_attr')->where(array('pid'=>0))->select();
			$this->display('Goods/goods_edit');
		}

	}


	public function attr_show()
	{ 
		$id =I('aid');
		if($id)
		{
			$data = M('admin_goods_attr')->where(array('pid'=>$id))->select();
				echo json_encode($data);
		}
	}

	public function attr()
	{
		$data = M('admin_goods_attr')->order('sort ASC')->select();

		$attr = Category::unlimitForLevel($data, '|--');

		$this->assign('attr', $attr);

		$this->display('Goods/goods_attr');
	}

	public function goods_add_attr()
	{
		$pid = I('pid', 0, 'intval');
		$this->assign('pid', $pid)->display('Goods/goods_attr_add');

	}

	public function goods_add_attr_handle()
	{
		$name = trim(I('name'));
		if (empty($name)) {
			$this->error('名称不能为空！');
		}

		$db = M('admin_goods_attr');
		if ($db->create()) {
			if ($db->add()) {
				$this->success('添加成功！', U('Goods/attr'), 1);
			} else {
				$this->error('添加失败！');

			}

		}
	}


	public function cate()
	{
		$cate = M('admin_goods_cate')->order('sort ASC')->select();

		$cate = Category::unlimitForLevel($cate, '|--');

		$this->assign('cate', $cate);

		$this->display('Goods/goods_cate_index');
	}


	public function goods_cate_add()
	{
		$pid = I('pid', 0, 'intval');
		$this->assign('pid', $pid)->display('Goods/goods_cate_add');
	}

	public function goods_cate_add_handle()
	{
		$name = trim(I('name'));
		if (empty($name)) {
			$this->error('名称不能为空！');
		}

		$db = M('admin_goods_cate');
		if ($db->create()) {
			if ($db->add()) {
				$this->success('添加成功！', U('Goods/cate'), 1);
			} else {
				$this->error('添加失败！');

			}

		}
	}

	public function goods_delete_attr()
	{
		if(M('admin_goods_attr')->where(array('id' => I('id')))->delete()){
			$this->success('删除成功！', U('Goods/attr'),1);
		} else {
			$this->error('删除失败！');
		}
	}

	public function edit_attr()
	{

	}

	public function goods_toTrash(){
		$type = $_GET['type'];
		$msg = $type ? '删除' : '还原';
		if(M('admin_goods')->where(array('id' => I('id')))->setField('del', $type)){
			$this->success($msg.'成功！');
		} else {
			$this->error($msg.'失败！');
		}
	}

	//彻底删除
	public function goods_delete(){
		if(D('Goods')->relation('attr')->delete($_GET['id'])){
			$this->success('彻底删除成功！');
		} else {
			$this->error('彻底删除失败！');
		}
	}

	//回收站视图
	public function goods_trash(){
		$this->goods = D('Goods')->where(array('del' => 1))->relation(true)->select();
		$this->display('Goods/goods_trash');
	}

	//清空回收站
	public function goods_emptyTrash(){
		if(D('Goods')->where(array('del' => 1))->relation('attr')->delete()){
			$this->success('清空回收站成功！');
		} else {
			$this->error('清空回收站失败！');
		}
		$this->display('Goods/goods_trash');
	}



}

