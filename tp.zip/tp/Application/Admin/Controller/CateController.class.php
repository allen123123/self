<?php
/**
 * Created by PhpStorm.
 * User: ALAN
 * Date: 2016/4/6
 * Time: 13:36
 */
namespace Admin\Controller;
use Think\Controller;
use Admin\lib\Category;
class CateController extends CommonController
{
    public function index(){
        $cate = M('admin_category')->order('sort ASC')->select();


        $cate = Category::unlimitForLevel($cate, '|--');

        $this->assign('cate',$cate);

        $this->display('Blog/blog_cate_index');

    }

    public function addCate(){
        $pid = I('pid', 0, 'intval');
        $this->assign('pid', $pid)->display('Blog/blog_cate_add');
    }

    //添加分类表单处理
    public function AddCateHandle(){
        $name = trim(I('name'));
        if(empty($name)) {
            $this->error('名称不能为空！');
        }

        $db = M('admin_category');
        if($db->create()){
            if($db->add()){
                $this->success('添加成功！', U('Cate/index'),1);
            } else {
                $this->error('添加失败！');

            }

        }
    }

    //删除分类
    public function deleteCate(){
        if(M('admin_category')->where(array('id' => I('id')))->delete()){
            $this->success('删除成功！', U('Cate/index'),1);
        } else {
            $this->error('删除失败！');
        }
    }

    //修改排序
    public function Blog_SortCateHandle(){
        $db = M('admin_category');
        foreach($_POST as $id => $sort){
            $db->where(array('id' => $id))->setField('sort', $sort);
        }

        $this->redirect('Cate/index');
    }

    public function Attr(){
        $attr = M('admin_attr')->select();
        $this->assign('attr', $attr)->display('Blog/Blog_Attr_index');
    }

    //添加属性视图
    public function AddAttr(){
        $this->display('Blog/Blog_Attr_add');
    }

    //添加属性表单处理
    public function AddAttrHandle(){
        $name = trim(I('name'));
        if(empty($name)) {
            $this->error('名称不能为空！');
        }

        $db = M('admin_attr');
        if($db->create()){
            if($db->add()){
                $this->success('添加成功！', U('Cate/Attr'),1);
            } else {
                $this->error('添加失败！');
            }

        }
    }

    //删除属性
    public function DeleteAttr(){
        if(M('admin_attr')->where(array('id' => I('id')))->delete()){
            $this->success('删除成功！', U('Cate/Attr'),1);
        } else {
            $this->error('删除失败！');
        }
    }

}

?>