<?php
namespace Admin\Controller;
use Think\Controller;
class ApiController extends Controller 
{
//2018��������ҳ��
public function index()
{
    $this-> orderinfo =M('ybm')->select();
    $this->display('admin_order');
}

}
