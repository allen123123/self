<?php
namespace Admin\Model;
use Think\Model;
class indexModel extends Model {

}