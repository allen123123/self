<?php
namespace Admin\Model;
use Think\Model;
class userModel extends Model {

}