<?php
namespace Admin\Model;
use Think\Model\RelationModel;
class GoodsModel extends RelationModel{
    protected $tableName = 'admin_goods';
    protected $_link = array(
        'attr' => array(
            'class_name'=> 'admin_goods_attr',
            'mapping_type' => self::MANY_TO_MANY,
            'foreign_key'  => 'gid',
            'relation_foreign_key' => 'aid',
            'relation_table' => 'admin_goods_rel',
        ),
        'category' => array(
            'class_name'=> 'admin_goods_cate',
            'mapping_type' => self::BELONGS_TO,
            'foreign_key' => 'cid',
            'mapping_fields' => 'name',
            'as_fields' => 'name:cate',
        ),
    );
}
?>