<?php
namespace Admin\Model;
use Think\Model\RelationModel;
class UserRelationModel extends RelationModel
{
    protected $tableName = 'admin_user';
    //定义关联关系
    protected $_link = array(
        'role' => array(                   //关联的表
            'mapping_type' => self::MANY_TO_MANY,	//多对多关系
            'class_name'        =>  'think_role',
            'foreign_key' => 'user_id',	//主表在中间表中的字段字称
            'relation_foreign_key' => 'role_id',	//副表在中间表中的名称
            'relation_table' => 'think_role_user',	//中间表名称
            'mapping_fields' => 'id, name, remark',	//显示的字段
        ),
        'area' => array(
            'class_name'=> 'area',
            'mapping_type' => self::BELONGS_TO,
            'foreign_key' => 'aid',
            'mapping_fields' => 'name',
            'as_fields' => 'name:area',
        ),
        'school' => array(
            'class_name'=> 'school',
            'mapping_type' => self::BELONGS_TO,
            'foreign_key' => 'sid',
            'mapping_fields' => 'name',
            'as_fields' => 'name:school',
        ),
//        'bkschool' => array(
//            'mapping_type' => self::MANY_TO_MANY,	//多对多关系
//            'class_name'        =>  'school',
//            'foreign_key' => 'uid',	//主表在中间表中的字段字称
//            'relation_foreign_key' => 'sid',	//副表在中间表中的名称
//            'relation_table' => 'school_rel',	//中间表名称
//            'mapping_fields' => 'id, name',	//显示的字段
//        ),
        'major' => array(
            'class_name'=> 'major',
            'mapping_type' => self::BELONGS_TO,
            'foreign_key' => 'mid',
            'mapping_fields' => 'name',
            'as_fields' => 'name:major',
        ),
    );
}
?>


