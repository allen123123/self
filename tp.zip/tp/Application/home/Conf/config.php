<?php
return array(
    'NOT_AUTH_MODULE' =>'Index',
    'NOT_AUTH_ACTION' =>'subject,subject_detail,subject_order,confirm_order,user_order,info,edit_info,imgupload,jsapi,cancelorder,sadjust,myadjust,nadjust,bookadjust,adsucess,course_detail,kcnr,loginout',

    //'URL_PATHINFO_DEPR'=>'-',
//    'TMPL_ENGINE_TYPE'=>'Smarty',
//    'TMPL_ENGINE_CONFIG' => array(
//        'caching' => TRUE,
//        'template_dir' => TMPL_PATH,
//        'compile_dir' => TEMP_PATH,
//        'cache_dir' => CACHE_PATH,
//        'left_delimiter' => '{',
//        'right_delimiter' => '}',
//    ),

);

