<?php
return array(
    'home\weixin'        =>    THINK_PATH.'home\lib\Weixin.class.php',
   
);