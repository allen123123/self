<?php
function d($array){
    dump($array,1,'<pre>',0);
}
?>