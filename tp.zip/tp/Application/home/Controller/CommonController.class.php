<?php

namespace home\Controller;
use Think\Controller;
use Org\Util\Rbac;
class CommonController extends Controller
{
    //public static $userid = '';

    public function _initialize()
    {

        if(C('USER_AUTH_ON')) Rbac::checkLogin();
        $notAuth =in_array(MODULE_NAME,explode(',',C('NOT_AUTH_MODULE'))) ||
            in_array(ACTION_NAME,explode(',',C('NOT_AUTH_ACTION')));
        if(!$notAuth) {
            Rbac::AccessDecision() || $this->error('没有权限',U('Login/index'),1);
        }
    }
}
?>