<?php
namespace home\Controller;
use Think\Controller;
use Org\Util\Rbac;
use home\lib\Category;


class CenterController extends CommonController
{
    public function index()
    {

        $this->data = D('FuserRelation')->where('userid='.session('uid'))->field('password', true)->relation(true)->find();
        session('bks',$this->data['bkschool']);
        session('bkm',$this->data['bkmid']);

        $this->display('Center/Index_usercenter');
    }

    public function confirm_order()
    {
        $id=I('oid');
        $this->data =M('admin_goods')->field('title,price,bnf_price')->find($id);
        $this->display('Center/Index_order_sub');
        session('orderinfo',$this->data['title']);
    }

    public function imgupload(){
        $upload = new \Think\Upload();// 实例化上传类
        $upload->saveName = 'time';
        $upload->maxSize   =     3145728 ;// 设置附件上传大小
        $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
        $upload->rootPath  =     'Public/'; // 设置附件上传根目录
        $upload->savePath  =     'Uploads/headimg/'; // 设置附件上传（子）目录
        // 上传文件
        $info   =   $upload->uploadOne($_FILES['user_img']);
        if(!$info) {// 上传错误提示错误信息
            $this->error($upload->getError());
        }else{// 上传成功

            $model=M('admin_user');
            $data['headimg']="http://www.daoshanedu.com".__ROOT__.'/'.'Public/'.$info['savepath'].$info['savename'];
            $model->where(array('userid'=>$_SESSION['uid']))->save($data);
            $this->ajaxReturn(array('info'=>1));
        }
    }



    public function jsapi()
    {
        $id=I('oid');
        if($id)
        {
            session('oid',$id);
            $info=M('user_order')->field('price,info')->find($id);
            $info['price']=substr($info['price'],3);
                    ini_set('date.timezone','Asia/Shanghai');
            Vendor('WxPayPubHelper.WxPayJsApiPay');
//            Vendor('WxPayPubHelper.log');
        $tools = new \JsApiPay();
        $openId = $tools->GetOpenid();
            Vendor('WxPayPubHelper.WxPayApi');
        $input = new \WxPayUnifiedOrder();
        $input->SetBody($info['info']);
        $input->SetAttach($info['info']);
        $input->SetOut_trade_no(\WxPayConfig::MCHID.date("YmdHis"));
        $input->SetTotal_fee("1");
        $input->SetTime_start(date("YmdHis"));
        $input->SetTime_expire(date("YmdHis", time() + 600));
        $input->SetGoods_tag($info['info']);
        $input->SetNotify_url("http://www.daoshanedu.com/pay/example/notify.php");
        $input->SetTrade_type("JSAPI");
        $input->SetOpenid($openId);
//1.
        $order = \WxPayApi::unifiedOrder($input);
//2.
        $jsApiParameters = $tools->GetJsApiParameters($order);
            $this->assign('jsApiParameters',$jsApiParameters);
            $this->assign
        $this->display('Center/Index_corder');
        }

    }

    public function orderstus()
    {

        $stus=I('status');
        if($stus)
        {

                $this->ajaxReturn(array('info' => 1));
            }

    }

    public function cancelorder()
    {
        $id=I('oid');
        $act=D('Order')->where(array('id'=>$id))->delete();
        if($act)
        {
            $this->ajaxReturn(array('msg'=>'删除成功'));
        }else{
            $this->ajaxReturn(array('msg'=>'删除失败'));
        }
    }
    public function subject_order()
    {
        if(!IS_AJAX) $this->ajaxReturn(array('msg'=>'非法参数'));
        $orderinfo=array(
            'info'=>session('orderinfo'),
            'username'=>I('name'),
            'QQ'=>I('qq'),
            'mobile'=>I('mobile'),
            'num'=>I('num'),
            'order_num'=>$this->build_order_no(),
            'price'=>trim(I('orderprice')),
            'date'=>time(),
            'status'=>0,
            'uid'=>session('uid'),
        );

        if(M('user_order')->add($orderinfo)) {
            $this->ajaxReturn(array('msg' => "添加订单成功",'info'=>1));

        }else{
            $this->ajaxReturn(array('msg'=>'添加订单失败','info'=>2));
        }
    }
    public function user_order()
    {
        $id=$_SESSION['uid'];
        $this->allorder =D('Order')->where(array('uid'=>$id))->select();
        $this->waitpay  =D('Order')->where(array('uid'=>$id,'status'=>0))->select();
        $this->pay      =D('Order')->where(array('uid'=>$id,'status'=>1))->select();

        $this->display('Center/Index_myorder');
    }
    public function subject()
    {
        $this->topcate = M('admin_goods_cate')->where(array('pid'=>0))->order('sort')->field('id,name')->select();
        $dmap['cid']=array(20);
        $dmap['is_show'] =array(1);
        $lmap['cid']=array(19);
        $lmap['is_show']=array(1);
        $this->sblistd  =D('Goods')->where($dmap)->order('sort')->relation(true)->select();
        $this->sblistl  =D('Goods')->where($lmap)->order('sort')->relation(true)->select();
        //优化方案:参考用blog文件里的list控制器里的方法,接受选中分类的ID传到后台判断显示的栏目
        $this->display('Center/Index_subject_center');
    }

    public function subject_detail()
    {
        $id =I('gid');

        $this->sdata =D('Goods')->relation(true)->field('sort,is_show,uptime,droptime,del',true)->find($id);
        session('orderinfo',$this->sdata['title']);

        M('admin_goods')->where(array('id'=>$id))->setInc('click');
        $this->display('Center/Index_subject_detail');


    }

    function build_order_no(){
        return date('Ymd').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);
    }

    public function info()
    {
        $id=$_SESSION['uid'];
        $this->info=M('admin_user')->field('name,nickname,aid,sid,mid,bkyear,bkschool,mobile,bkmid,headimg')->find($id);
        $this->display('Center/Index_personalinfo');
    }

    public function edit_info()
    {
        if(!IS_AJAX) $this->error('非法参数');
        $info =array(
            'aid'=>I('aid'),
            'sid'=>I('byCollage'),
            'mid'=>I('bymajor'),
            'bkschool'=>I('bcCollage'),
            'bkmid'=>I('bcMajor'),
            'bkyear'=>I('bky'),
            'mobile'=>I('mobile'),
        );
        if(isset($_POST['uid']))
        {

            M(admin_user)->where(array('userid'=>$_POST['uid']))->save($info);
            $this->ajaxReturn(array('info'=>1));

        }else{
            $this->ajaxReturn(array('msg'=>'修改失败'));
        }
    }

    public function myadjust()
    {
        $id=I('uid');
        if($id)
        {
            $isset =M('myadjust')->where(array('uid'=>$id))->find();
            $data=array(
                'uid'=>$id,
                'userName'=>I('userName'),
                'byCollage'=>I('byCollage'),
                'bcCollage'=>I('bcCollage'),
                'bcMajor'=>I('bcMajor'),
                'contact'=>I('contact'),
                'message'=>I('message'),
                'updatatime'=>time(),
                'courseName1'=>I('courseName1'),
                'courseName2'=>I('courseName2'),
                'courseName3'=>I('courseName3'),
                'point1'=>I('point1','','intval'),
                'point2'=>I('point2','','intval'),
                'point3'=>I('point3','','intval'),
                'majorName1'=>I('majorName1'),
                'majorName2'=>I('majorName2'),
                'mpoint1'=>I('mpoint1','','intval'),
                'mpoint2'=>I('mpoint2','','intval'),
            );

            if(!$isset) {
                M('myadjust')->where(array('uid'=>$id))->add($data);
                $this->ajaxReturn(array('info'=>1));
            }else if($isset){
                M('myadjust')->where(array('uid'=>$id))->save($data);
                $this->ajaxReturn(array('info'=>1));
            }
        }else{

            $id=$_SESSION['uid'];
            $this->data=M('myadjust')->where(array('uid'=>$id))->find();

            $this->display('Center/Index_myadjust');
        }


    }
    public function bookadjust()
    {

        $id=I('uid');
        if($id)
        {
            $isset =M('myadjust')->where(array('uid'=>$id))->find();
           $data=array(
               'updatatime'=>time(),
               'bookCollage1'=>I('bookCollage1'),
               'bookCollage2'=>I('bookCollage2'),
               'bookCollage3'=>I('bookCollage3'),
               'bookMajor1'=>I('bookMajor1'),
               'bookMajor2'=>I('bookMajor2'),
           );

            if(!$isset)
            {
                M('myadjust')->where(array('uid'=>$id))->add($data);
                $this->ajaxReturn(array('info'=>1));
            }
            else if($isset){
                M('myadjust')->where(array('uid'=>$id))->save($data);
                $this->ajaxReturn(array('info'=>1));

            }
        }else{
            $id=$_SESSION['uid'];
            $this->data=M('myadjust')->where(array('uid'=>$id))->find();
            $this->display('Center/Index_bookadjustInfo');
        }
    }

    public function adsucess()
    {
        $this->display('Center/Index_compltedadjust');
    }

    public function loginout()
    {
        session_unset();
        session_destroy();
        $this->redirect('Login/index');
    }



}
?>