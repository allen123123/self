<?php
namespace home\Controller;
use Think\Controller;
use Org\Util\Rbac;

class LoginController extends Controller
{
    public static $appid = wx0399e5cc514651ec;

    public function index()
    {
        $this->display('Index_login');
    }

    public function check()
    {
        if(!IS_AJAX)   $this->error('非法参数');
        $mobile =I('mobile');
        $password =I('post.password','','md5');

        $user = M('admin_user')->where(array('mobile'=>$mobile))->find();
        if(!$user || $user['password']!=$password)
        {
            $Msg['msg']='手机或密码错误';
            $this->ajaxReturn($Msg);

        }
//        $code     =I('post.verify');
//
//        if(!verify_check($code))
//        {
//            $Msg['msg']='验证码错误';
//            $this->ajaxReturn($Msg);
//
//        }
        if($v=I('rember')==1)
        {
            cookie('mobile',$mobile,3600*24*30);
        }
        if($user['vip'] ==0) {$Msg['msg']='你这是哪里的帐号啊'; $this->ajaxReturn($Msg);}
        if($user['is_lock'] ==1) {$Msg['msg']='帐号被锁定';  $this->ajaxReturn($Msg);}
//        if($user['status'] ==0) {$Msg['msg']='你未通过审核'; $this->ajaxReturn($Msg);}
        if($user['status'] ==2) {$Msg['msg']='你不通过审核';  $this->ajaxReturn($Msg);}

        $data =array(
            'userid'=>$user['userid'],
            'logintime'=>time(),
            'loginip'=>get_client_ip(),
            'loginnum'=>$user['loginnum']+1,
        );
        M('admin_user')->save($data);
        session(C('USER_AUTH_KEY'),$user['userid']);
        session(array('name'=>'uid','expire'=>10));
        session('username',$user['name']);
        session('nickname',!empty($user['nickname'])?$user['nickname']:$this->getRandChar(3));
        session('logintime',date('Y-m-d H:i:s',$user['logintime']));
        session('bks',$user['bkschool']);
        session('bkm',$user['bkmid']);
        Rbac::saveAccessList($user['userid']);
        $this->ajaxReturn(array('info'=>1));
    }

    public function rps()
    {

    }
    public function verify()
    {
        ob_clean();   //请缓存
        $verify = new \Think\Verify();

        // 配置验证码参数
        $verify->fontSize = 18;     // 验证码字体大小
        $verify->length =2;        // 验证码位数
        $verify->imageH = 38;       // 验证码高度
        $verify->useImgBg = false;   // 开启验证码背景
        $verify->useNoise = false;  // 关闭验证码干扰杂点
        $verify->reset =false;
        $verify->entry();
    }

    public function loginout()
    {
        session_unset();
        session_destroy();
        $this->redirect('index');
    }
    public function reg()
    {
        if(!IS_AJAX) $this->error('illegal parameter');
        if (IS_AJAX) {
            // 实例化User对象
            $user = D('user');
            // 自动验证 创建数据集
            if (!$data =$user->create()) {
                // 防止输出中文乱码
                header("Content-type: text/html; charset=utf-8");
                $this->ajaxReturn($user->getError());
            }
            $code =I('code','','intval');
            if($code !=$_SESSION['vcode']||empty($_SESSION['vcode']))
            {
                $this->ajaxReturn(array('msg'=>'短信验证码错误'));
            }
            //插入数据库
            if ($user->add($data)) {
                $uid= M('admin_user')->where(array('mobile'=>$data['mobile']))->find();
                $arr['role_id']='6';
                $arr['user_id']=$uid['userid'];
                M('think_role_user')->add($arr);
                $this->ajaxReturn(array('info'=>1));
            } else {
                $this->ajaxReturn(array('msg'=>'注册失败'));
            }
        }
    }
    function Get($url){
        $ch = curl_init();
        $timeout = 20;
        $post_data = "account=gzhtjy&pswd=GZhtjy27&mobile=".session('reg_mobile')."&msg=您好,你的注册信息验证码:".session('vcode')."【道善教育】&needstatus=false&product=";
        curl_setopt ($ch, CURLOPT_URL, $url);
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        //post数据
        curl_setopt($ch, CURLOPT_POST, 1);
        //post的变量
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        $file_contents = curl_exec($ch);
        curl_close($ch);
        return $file_contents;
    }

    public function getcode()
    {
        $url='http://120.24.167.205/msg/HttpSendSM';
        if(!IS_AJAX) $this->error('illegal parameter');
        //js发来的随机验证码数字
        $code=I('vcode');
        session('vcode',$code);
        $mobile=I('mobile',0,intval);
        if($code) {
            session('reg_mobile', $mobile);
            $this->Get($url);
        }
    }

    public function getRandChar($length){
        $str = null;
        $strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
        $max = strlen($strPol)-1;

        for($i=0;$i<$length;$i++){
            $str.=$strPol[rand(0,$max)];//rand($min,$max)生成介于min和max两个数之间的一个随机整数
        }

        return 'User_'.$str;
    }

    public function curl_get_weixin_token(){

        $TOKEN = file_get_contents("https://api.weixin.qq.com/sns/oauth2/access_token?appid=".self::$appid."&secret=4d40ab3a9d88f3dd4a93a40f1c17fdd5&code=".$_GET['code']."&grant_type=authorization_code");
        $TOKEN_json = json_decode($TOKEN,true);
        $TOKEN_json['get_token_time'] = time();
        session('retoken',$TOKEN_json['refresh_token']);
        session('openid',$TOKEN_json['openid']);
        session('token',$TOKEN_json['access_token']);
        session('token1time',$TOKEN_json['get_token_time']);
//        file_put_contents($this->weixin_token_file(),json_encode($TOKEN_json));//保存到本地
//        return $TOKEN_json;
    }

    public function get_weixin_token(){
        //去微信获取，然后保存
        $now_time = time();
//        $get_local_token = file_get_contents(self::weixin_token_file());
        $token_array = session('token');
        //判断本地的weixin_token是否存在
        if( !isset($token_array) ){
            //去微信获取，然后保存
            $this->curl_get_weixin_token();
            $token_array = session('token');
        }
        else{
            //判断 当前时间 减去 本地获取微信token的时间 大于7000秒 ,就要重新获取
            if( $now_time - session('token1time') >7100 ){
//                $token_array = $this->curl_get_weixin_token();
                //通过第一个refresh_token获取长期的access_token
                $dataurl= 'https://api.weixin.qq.com/sns/oauth2/refresh_token?appid='.self::$appid.'&grant_type=refresh_token&refresh_token='.session("retoken");
                $tokendata =json_decode(file_get_contents($dataurl),true);
                $token_array=$tokendata['access_token'];
                session('openid',$tokendata['openid']);
                session('token',$tokendata['access_token']);
            }
        }
        return $token_array;
    }
//    public function weixin_token_file(){
//        return dirname(__FILE__).'/log/get_token.txt';
//    }
    public function getwxid(){

        $token=$this->get_weixin_token();
        $user_info_url = 'https://api.weixin.qq.com/sns/userinfo?access_token='.$token.'&openid='.$_SESSION["openid"].'&lang=zh_CN';
        $user_info = json_decode(file_get_contents($user_info_url),true);
        $matchuser =M('admin_user')->where(array('openid'=>$_SESSION["openid"]))->find();

        if(!$matchuser) {
            $saveuser =array(
                'openid'=>$user_info['openid'],
                'vip'=>1,
                'status'=>1,
                'time'=>time(),
                'nickname'=>$user_info['nickname'],
                'headimg' =>$user_info['headimgurl'],
            );
            if(M('admin_user')->add($saveuser))
            {
                $uid= M('admin_user')->where(array('nickname'=>$saveuser['nickname']))->find();
                $arr['role_id']='9';
                $arr['user_id']=$uid['userid'];
                M('think_role_user')->add($arr);
                $this->data= D('FuserRelation')->where(array('nickname'=>$saveuser['nickname']))->field('password', true)->relation(true)->find();
                session('uid',$uid['userid']);
                session('nickname',$uid['nickname']);
                session('bks',$uid['bkschool']);
                session('bkm',$uid['bkmid']);
                Rbac::saveAccessList($uid['userid']);
                $this->display('Center/Index_usercenter');
            }
        }else {
            session('uid',$matchuser['userid']);
            session('nickname',$matchuser['nickname']);
            Rbac::saveAccessList($matchuser['userid']);
            session('bks',$matchuser['bkschool']);
            session('bkm',$matchuser['bkmid']);
            $this->data =D('FuserRelation')->where(array('openid' =>$user_info['openid']))->field('password', true)->relation(true)->find();
            $this->display('Center/Index_usercenter');
        }
    }
}
?>