<?php
namespace home\Controller;
use Think\Controller;
class IndexController extends CommonController {
    public function index(){
        
        $this->display('index');

        }

    public function comment()
    {

        $this->display();
    }

    public function check_comment()
    {
        if (!IS_AJAX)
            $this->ajaxReturn(array(
                'info' => "非法参数"
            ));
            $filter = array(
                'username' => I('username', '', 'htmlspecialchars'),
                'email' => I('post.email', '', 'email'),
                'tel' => I('tel', '', 'htmlspecialchars'),
                'comment' => I('comment', '', 'htmlspecialchars'),
                'date' => time(),
                // 'userid'  =>session('uid'),
            );
            if (M('comment')->data($filter)->add()) {
                $msg = array(
                    'info' => 'ok',
                    'callback' => U('comment', '', ''),
                );
            } else {
                $msg = array(
                    'info' => '提交失败'
                );
            }
            $this->ajaxReturn($msg);
        }

}