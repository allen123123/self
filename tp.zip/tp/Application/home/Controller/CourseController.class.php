<?php
namespace home\Controller;
use Think\Controller;
use Org\Util\Rbac;
use home\lib\Category;

class CourseController extends CommonController
{
    public function index()
    {

        $this->catelist = M('admin_course_cate')->where(array('pid' => 0))->field('id,name')->order('id ASC')->select();
        $this->list =M('admin_course')->field('id,name,coverimg,is_show,summary')->order('click desc')->limit(5)->select();
        $this->display('Course/Index_course_center');
    }


    public function course_detail()
    {
            $id=I('cid');
            M('admin_course')->where(array('id' => $id))->setInc('click');
            $this->info = D('Course')->relation(true)->find($id);
            $this->display('Course/Index_course_detail');

    }

    public function kyggk()//考研公共课
    {
        $cate = M('admin_course_cate')->select();
        $cid =Category::getChildsId($cate,1);
        $where=array('id'=>array('IN',$cid));
        $this->nav =M('admin_course_cate')->where($where)->select();
        if($id=I('subid'))
        {
            $data =D('Course')->where(array('cid'=>$id))->limit(5)->select();
            $this->ajaxReturn($data);
        }else{
            $all =M('admin_course_cate')->where(array('pid'=>1))->select();
            $allid=Category::getChildsId($all,1);
            $where=array('cid'=>array('IN',$allid));
            $this->data=D('Course')->getAll($where,5);
        }
        $this->display('Course/Index_publicousre');

    }

    public function tkzyk()//统考专业课
    {
        $cate = M('admin_course_cate')->select();
        $cid =Category::getChildsId($cate,4);
        $where=array('id'=>array('IN',$cid));
        $this->nav =M('admin_course_cate')->where($where)->select();
        if($id=I('subid'))
        {
            $data =D('Course')->where(array('cid'=>$id))->limit(5)->select();
            $this->ajaxReturn($data);
        }else{
            $all =M('admin_course_cate')->where(array('pid'=>4))->select();
            $allid=Category::getChildsId($all,4);
            $where=array('cid'=>array('IN',$allid));
            $this->data=D('Course')->getAll($where,5);
        }
        $this->display('Course/Index_specializedCourse');

    }

    public function ftkzyk()//非统考专业课
    {
        $cate = M('admin_course_cate')->select();
        $cid =Category::getChildsId($cate,4);
        $where=array('id'=>array('IN',$cid));
        $this->nav =M('admin_course_cate')->where($where)->select();

        $this->display('Course/Index_unspecializedCourse');

    }

    public function zyssk()//专业硕士
    {


        $this->display('Course/Index_pro_master');
    }


    public function kcnr() //课程内容
    {
        $this->display('Course/Index_course_sort_conc');
    }
}
?>