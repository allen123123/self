<?php 
namespace home\Controller;
use Think\Controller;

class TestController extends Controller
{

//2018����Ԥ������������
    public function test()
    {
        if(!IS_AJAX) $this->error('�Ƿ�����');
        $data = array(

            'name'=>I('name'),
            'mobile'=>I('mobile'),
            'time'=>time(),
            'school'=>I('bkschool'),
            'bkmajor'  => I('bkmajor'),
            'vip'=>I('vip'),
            'kymajor'=>I('kymajor'),
        );
        if(M('ybm')->add($data))
        {
            $Msg['msg']='Pay success'; $this->ajaxReturn($Msg);
        }else{
            $Msg['msg']='Pay Fail'; $this->ajaxReturn($Msg);

        }
    }

    public function pp()
    { if(!IS_AJAX) $this->error('�Ƿ�����');
        $data = array(

           'status'=>I('status'),
        );
        if($data)
        {
            $this->ajaxReturn(array('info'=>1));
        }

    }
}

