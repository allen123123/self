<?php
namespace home\Controller;
use Think\Controller;
use Org\Util\Rbac;
use home\lib\Category;
class UserController extends Controller {


    public function index()
    {
        $this -> display('test/personal_center');
    }

    public function subject(){

        $total = M('admin_goods') -> count(); # 总记录数

        $limit = 2;

        $page = new \Think\Page($total, $limit);

        $page -> lastSuffix = false;

        $page -> setConfig('first','首页');

        $page -> setConfig('last','尾页');

        $page -> setConfig('theme','%FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END%');

        $this -> page = $page -> show();

        $this -> goods = D('Goods') -> page(I('get.p',1),$limit ) -> relation(true) -> select();

        $this-> display('test/subject_center');

    }

    public function detail(){

        $this -> goods = D('Goods') -> relation(true) -> select();
        
        $this -> display('test/subject_detail');
    }
}