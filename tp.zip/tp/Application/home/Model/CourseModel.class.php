<?php
namespace home\Model;
use Think\Model\RelationModel;
class CourseModel extends RelationModel
{
    protected $tableName = 'admin_course';
    protected $_link = array(
        'attr' => array(
            'class_name'=> 'admin_course_attr',
            'mapping_type' => self::MANY_TO_MANY,
            'foreign_key'  => 'cid',
            'relation_foreign_key' => 'aid',
            'relation_table' => 'admin_course_rel',
        ),
        'category' => array(
            'class_name'=> 'admin_course_cate',
            'mapping_type' => self::BELONGS_TO,
            'foreign_key' => 'cid',
            'mapping_fields' => 'name',
            'as_fields' => 'name:cate',
        ),
    );
    public function getAll($where, $limit){
        return $this->where($where)->order('click DESC')->limit($limit)->select();
    }
}?>