<?php
namespace home\Model;
use Think\Model\RelationModel;

class AdjustModel extends RelationModel
{
    protected $tableName = 'myadjust';
    protected $_link = array(
        'order' => array(
            'class_name'=> 'admin_user',
            'mapping_type' => self::BELONGS_TO,
            'foreign_key' => 'uid',
            'mapping_fields' => 'name',
            'as_fields' => 'name:username',
        ),
    );
}
?>