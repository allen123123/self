<?php
namespace home\Model;
use Think\Model\ViewModel;

class SubjectModel extends ViewModel
{
    protected $viewFields = array(
        'admin_goods' => array(
            'id', 'title', 'price', 'bnf_price', 'uptime','droptime',
        ),
        'admin_category' => array(
            'name', '_on' => 'admin_goods.cid = admin_category.id'
        )
    );

    public function getAll($where, $limit){
        return $this->where($where)->order('time DESC')->limit($limit)->select();
    }

}
