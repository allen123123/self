<?php
namespace home\Model;
use Think\Model\RelationModel;

class OrderModel extends RelationModel
{
    protected $tableName = 'user_order';
    protected $_link = array(
        'order' => array(
            'class_name'=> 'admin_user',
            'mapping_type' => self::BELONGS_TO,
            'foreign_key' => 'uid',
            'mapping_fields' => 'info',
            //'as_fields' => 'info:cate',
        ),
    );
}
?>