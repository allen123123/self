<?php
namespace home\Model;
use Think\Model;
class IndexModel extends Model {

}